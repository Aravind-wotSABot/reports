
import Sidebar from '../Sidebar'

const SalesMetricsReports = () => {
  return (
    <div className="flex h-screen bg-gray-100">
      <Sidebar />SalesMetricsReports</div>
  )
}

export default SalesMetricsReports