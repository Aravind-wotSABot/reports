
import Sidebar from '../Sidebar'

const InvoiceReports = () => {
  return (
    <div className="flex h-screen bg-gray-100">
      <Sidebar />InvoiceReports</div>
  )
}

export default InvoiceReports