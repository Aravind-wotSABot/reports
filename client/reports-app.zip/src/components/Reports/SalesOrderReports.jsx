
import Sidebar from '../Sidebar'

export const SalesOrderReports = () => {
  return (
    <div className="flex h-screen bg-gray-100">
      <Sidebar />SalesOrderReports</div>
  )
}
