import { AgGridReact } from "ag-grid-react";
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-quartz.css";
import Sidebar from "../Sidebar";
import { useMemo, useState } from "react";
import SearchBar from "../SearchBar";

const LeadReports = () => {
  const [rowData, setRowData] = useState([
    {
      report_name: "Todays Leads",
      description: "Leads obtained today",
    },
    {
      report_name: "Leads by Status",
      description: "Leads and their statuses",
    },
    {
      report_name: "Leads by Source",
      description: "Leads from various sources",
    },
    {
      report_name: "Leads by Ownership",
      description: "Leads by Owner",
    },
    {
      report_name: "Leads by Industry",
      description: "Leads by industry",
    },
    {
      report_name: "Converted Leads",
      description: "Leads converted to Account/Deal/Contact",
    },
  ]);
  const [columnDefs, setColumnDefs] = useState([
    {
      field: "report_name",
      headerName: "Report Name",
      headerCheckboxSelection: true,
      checkboxSelection: true,
      flex: 1,
    },
    {
      field: "description",
      headerName: "Description",
      flex: 2,
    },
  ]);

  const defaultColDef = useMemo(() => {
    return {
      filter: true,
    };
  }, []);

  return (
    <div className="flex h-screen bg-gray-100">
      {/* Sidebar */}
      <Sidebar />
      {/* Main Content */}
      <div className="w-full m-16">
        <div className="flex justify-end mb-6">
          <SearchBar />
        </div>

        {/* Table */}

        <div className="ag-theme-quartz">
          <AgGridReact
            rowData={rowData}
            columnDefs={columnDefs}
            rowSelection={"multiple"}
            domLayout="autoHeight"
            defaultColDef={defaultColDef}
          />
        </div>
      </div>
    </div>
  );
};

export default LeadReports;
