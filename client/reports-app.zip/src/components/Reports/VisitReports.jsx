import Sidebar from "../Sidebar";

export const VisitReports = () => {
  return (
    <div className="flex h-screen bg-gray-100">
      <Sidebar />
      VisitReports
    </div>
  );
};
