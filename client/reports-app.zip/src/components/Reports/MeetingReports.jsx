
import Sidebar from '../Sidebar'

const MeetingReports = () => {
  return (
    <div className="flex h-screen bg-gray-100">
      <Sidebar />MeetingReports</div>
  )
}

export default MeetingReports