import Sidebar from '../Sidebar'

const DealReports = () => {
  return (
    <div className="flex h-screen bg-gray-100">
      <Sidebar />DealReports</div>
  )
}

export default DealReports